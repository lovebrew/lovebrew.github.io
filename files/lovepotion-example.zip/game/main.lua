function love.draw(screen)
    local width, height = love.graphics.getDimensions(screen)
    love.graphics.print('Hello World!', width / 2, height / 2)
end

-- we need to quit the app when a button is pressed
function love.gamepadpressed(joystick, button)
    love.event.quit()
end